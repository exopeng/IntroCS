import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter a dimension: ");
    int dim = Integer.parseInt(scanner.nextLine());
    int[][] spiral = new int[dim][dim];
    int lineLen = dim;
    spiral = spiralShaper(spiral, dim, lineLen);
    spiralPrinter(spiral);

  }
  public static int[][] spiralShaper(int[][] testArray, int dim, int lineLen) {
    int num = 0;
    int rowOrCol = 0;
    boolean leftToRight = false;
    boolean topToBottom = false;
    int startPos = 0;
    for (int i = 0; i < dim * 2 - 1; i++) {
      System.out.println();
      lineLen = lineReducer(lineLen, i);
      if (i % 2 == 0) {
        leftToRight = horizontalDirectionSetter(leftToRight);
      } else {
        topToBottom = verticalDirectionSetter(topToBottom);
      }
      

      for (int k = 0; k < lineLen; k++) {
        num++;
        if (i % 2 == 0) {
          if (leftToRight) {
            testArray[rowOrCol][startPos] = num;
            startPos++;
            
          } else {
            testArray[rowOrCol][startPos] = num;
            startPos--;
            
          }
        } else { 
          if (topToBottom) {
            testArray[startPos][rowOrCol] = num;
            startPos++;
            
          } else {
            testArray[startPos][rowOrCol] = num;
            startPos--;
            
          }
        }
      }
      
      int temp = rowOrCol;
      int temp1 = startPos;
      
      if (i % 2 == 0) {
        if (leftToRight == true) {
          startPos = temp + 1;
          rowOrCol = temp1 - 1;
        } else {
          startPos = temp - 1;
          rowOrCol = temp1 + 1;
        }

      } else {
        if (topToBottom == true) {
          startPos = temp - 1;
          rowOrCol = temp1 - 1;
        } else {
          startPos = temp + 1;
          rowOrCol = temp1 + 1;
        }
      }
      
    }

    return testArray;
  }

  public static int lineReducer(int lineLen, int i) {
    if (i % 2 == 1) {
      lineLen--;
    }
    return lineLen;
  }

  public static boolean horizontalDirectionSetter(boolean leftToRight) {
      if(leftToRight == true) {
          leftToRight = false;
      } else {
        leftToRight = true;
      }
      return leftToRight;
  }
   public static boolean verticalDirectionSetter(boolean topToBottom) {
      if(topToBottom == true) {
          topToBottom = false;
      } else {
        topToBottom = true;
      }
      return topToBottom;
  }
  public static void spiralPrinter(int[][] newArray) {
      for (int i = 0; i < newArray.length; i++) {
        for (int j = 0; j < newArray[0].length; j++) {
          System.out.print(newArray[i][j] + " ");
        }
        System.out.println();
      }
  }
}
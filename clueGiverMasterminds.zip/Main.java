class Main {
  public static void main(String[] args) {
  }

  public static int[] evaluate(int[] newSolution, int[] newGuess) {
    int numCorrect = 0;
    int numClose = 0;
    int numWrong = 0;
    
    int[] check = new int[] {numCorrect, numClose, numWrong};
    for (int c = 0; c < 5; c++) {
      for (int i = 0; i < newSolution.length; i++ ) {
        if (newGuess[i] == newSolution[i]) {
          numCorrect++;
          newSolution = eliminater(newSolution, i);
          newGuess = eliminater(newGuess, i);
          
          for (int j = 0; j < newGuess.length; j++) {
            System.out.print(newSolution[j] + " ");
          }
          System.out.println();
          for (int j = 0; j < newGuess.length; j++) {
            System.out.print(newGuess[j] + " ");
          }
          System.out.println();
        }
      }
    }
    for (int i = 0; i < newGuess.length; i++) {
      boolean solFound = false;
      int j = 0;
      while (solFound == false) {
        if (newGuess[i] == newSolution[j]) {
          solFound = true;
          numClose++;
        }
        
        if (j == newGuess.length - 1) {
          solFound = true;
        }
        j++;
      }
    }
    numWrong = 5 - (numClose + numCorrect);
    System.out.println(numCorrect);
    System.out.println(numClose);
    System.out.println(numWrong);
    return check;
  }

  public static int[] eliminater(int[] array, int eliminee) {
    int[] returner = new int[array.length - 1];
    int counter = 0;
    for (int i = 0; i < array.length; i++) {
      if (i != eliminee) {
        returner[counter] = array[i];
        counter++; 
      }
    }
    return returner;
  }
}